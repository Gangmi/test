package sujeburger_GUI;

import javax.swing.JFrame;

public class test {

	public static void main(String[] args) {
		
		
		
	}

}
